"""
MAXIMUM-RIGOR PASS, Item 11: a SECOND MODEL FAMILY for the
real-feature Mechanism-3 harness. code/43 / code/78's real-feature results
(§4.3, Table tab:m3-real) use a single model (Mistral-7B-Instruct-v0.2-AWQ)
and a single dataset (HaluEval qa_samples). This kernel reruns the identical
extraction-then-leakage-test pipeline on a SECOND model family (Qwen2.5-7B-
Instruct-AWQ) with the SAME dataset, holding everything else fixed, to test
whether the mechanism's real-feature severity is model-specific or transports
across architectures -- directly the "fidelity gradient" / cross-family
generalization question Limitation (8) in main.tex raises but does not test.

Everything downstream of feature extraction (extract_features,
SweepMLP/LEAKY/CLEAN/CLEAN_MATCHED/PLACEBO, capacity=128, epochs=45,
ES_HOLD_FRACTION=0.15, n_seeds=100) is an EXACT, unmodified copy of
kaggle_runs/real-feature-v2/run_real_feature_leakage_test.py. Only
MODEL_ID changes.

DISCLOSED LIMITATION vs the Mistral run: the Mistral kernel pins an exact
model + dataset revision hash (closing a previously-flagged reproducibility
gap for THIS PAPER's primary real-feature result). This exploratory second-
family run does not repeat that pinning exercise for Qwen (only the dataset
revision is pinned, matching the primary run) -- acceptable for an exploratory
transport check reported as such, not for a primary result.
"""
import os, sys, json, gc, time, subprocess

try:
    import gptqmodel  # noqa: F401
except ImportError:
    subprocess.run([sys.executable, "-m", "pip", "install", "-q", "gptqmodel"], check=True)

try:
    import autoawq  # noqa: F401
except ImportError:
    subprocess.run([sys.executable, "-m", "pip", "install", "-q", "autoawq"], check=True)

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from datasets import load_dataset
from scipy.stats import norm, wilcoxon
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import StratifiedKFold, train_test_split
from sklearn.preprocessing import StandardScaler
from transformers import AutoModelForCausalLM, AutoTokenizer
from pathlib import Path

OUT = Path("/kaggle/working")
OUT.mkdir(parents=True, exist_ok=True)

if not torch.cuda.is_available():
    raise RuntimeError("No CUDA device visible -- this kernel needs a GPU accelerator "
                       "(AWQ requires a compatible GPU; there is no CPU fallback for a 7B AWQ model).")
try:
    _a = torch.randn(4, 4, device="cuda") @ torch.randn(4, 4, device="cuda")
    print(f"GPU sanity check passed: {torch.cuda.get_device_name(0)}")
except Exception as e:
    raise RuntimeError(f"GPU sanity check failed on {torch.cuda.get_device_name(0)} -- "
                       f"likely an incompatible accelerator was assigned. Re-push and retry. "
                       f"Original error: {e}")

MODEL_ID = "Qwen/Qwen2.5-7B-Instruct-AWQ"
# NOT pinned to a specific revision hash (disclosed limitation above); dataset
# revision IS pinned, matching the primary Mistral run exactly.
DATASET_REVISION = "12a856119f03975a94509091e8cada3e6be6ead7"
N_SAMPLES = 400          # matches the primary Mistral run exactly
N_SAMPLE_LAYERS = 32
ANCHOR_FRACTIONS = [0.25, 0.50, 0.75, 1.00]

FEATS_PATH = OUT / "real_features_qwen2.5_7b_halueval.npz"


# ── MultiHaluDet's own feature-extraction code, copied verbatim (model-agnostic) ──

def safe_stat(tensor, func, default=0.0):
    try:
        val = func(tensor)
        if isinstance(val, torch.Tensor):
            val = val.item()
        return val if not (np.isnan(val) or np.isinf(val)) else default
    except Exception:
        return default


def get_sampled_layer_indices(n_total_layers, n_sample):
    if n_total_layers <= 0:
        raise ValueError(f"Model reported {n_total_layers} transformer layers")
    if n_total_layers <= n_sample:
        indices = list(range(1, n_total_layers + 1))
        while len(indices) < n_sample:
            indices.append(indices[-1])
        return indices
    return [
        max(1, min(n_total_layers, round(1 + (n_total_layers - 1) * i / (n_sample - 1))))
        for i in range(n_sample)
    ]


def get_anchor_stats(seq_feats, sampled_indices, n_total_layers, anchor_fractions):
    sampled_arr = np.array(sampled_indices)
    anchor_stats = {}
    for pos, frac in enumerate(anchor_fractions):
        target_layer = max(1, min(n_total_layers, round(frac * n_total_layers)))
        closest_rank = int(np.argmin(np.abs(sampled_arr - target_layer)))
        anchor_stats[pos] = seq_feats[closest_rank]
    return anchor_stats


def compute_kurtosis(x):
    mu = x.mean()
    std = x.std()
    if std < 1e-9:
        return 0.0
    return torch.mean(((x - mu) / std) ** 4)


def compute_mad(x):
    med = torch.median(x)
    return torch.median(torch.abs(x - med))


class Cfg:
    n_sample_layers = N_SAMPLE_LAYERS
    anchor_fractions = ANCHOR_FRACTIONS


def extract_features(question, answer, tokenizer, model_llm, config):
    prompt = f"Question: {question}\nAnswer: {answer}"
    inputs = tokenizer(prompt, return_tensors="pt", truncation=True, max_length=256).to(model_llm.device)
    with torch.no_grad():
        outputs = model_llm(**inputs, output_hidden_states=True)
    hidden_states = outputs.hidden_states
    logits = outputs.logits[0, -1].float()
    n_total_layers = len(hidden_states) - 1
    sampled_indices = get_sampled_layer_indices(n_total_layers, config.n_sample_layers)

    seq_feats = []
    for layer_idx in sampled_indices:
        hs = hidden_states[layer_idx][0].float()
        last_hs = hs[-1]
        f = [
            safe_stat(last_hs, lambda x: torch.norm(x)),
            safe_stat(last_hs, lambda x: x.mean()),
            safe_stat(last_hs, lambda x: x.std()),
            safe_stat(last_hs, lambda x: x.min()),
            safe_stat(last_hs, lambda x: x.max()),
            safe_stat(last_hs, lambda x: (x > 0).float().mean()),
            safe_stat(last_hs, lambda x: (x.abs() < 0.1).float().mean()),
            safe_stat(last_hs, lambda x: -(F.softmax(x, dim=0) * torch.log(F.softmax(x, dim=0) + 1e-9)).sum()),
            safe_stat(last_hs, compute_kurtosis),
            safe_stat(last_hs, compute_mad),
        ]
        mean_hs = hs.mean(dim=0)
        f.extend([safe_stat(mean_hs, lambda x: torch.norm(x)), safe_stat(mean_hs, lambda x: x.std())])
        seq_feats.append(f)

    anchor_stats = get_anchor_stats(seq_feats, sampled_indices, n_total_layers, config.anchor_fractions)
    probs = F.softmax(logits, dim=-1)
    top_k = torch.topk(probs, k=min(10, len(probs)))
    logit_entropy = -torch.sum(probs * torch.log(probs + 1e-10)).item()
    logit_std = logits.std().item()
    logit_max = logits.max().item()
    glob_feats = [
        top_k.values[0].item(),
        top_k.values[1].item() if len(top_k.values) > 1 else 0,
        (top_k.values[0] - top_k.values[1]).item() if len(top_k.values) > 1 else top_k.values[0].item(),
        logit_entropy, logit_std, logit_max,
    ]
    if len(top_k.values) >= 3:
        glob_feats.extend([top_k.values[2].item(), (top_k.values[0] - top_k.values[2]).item()])
    else:
        glob_feats.extend([0, 0])
    norms = [f[0] for f in seq_feats]
    norm_diffs = np.diff(norms)
    glob_feats.extend([
        np.mean(norm_diffs), np.std(norm_diffs),
        np.max(norm_diffs) if len(norm_diffs) > 0 else 0,
        np.min(norm_diffs) if len(norm_diffs) > 0 else 0,
        norms[-1] / (norms[0] + 1e-6), norms[-1] - norms[0],
    ])
    for pos in range(len(config.anchor_fractions)):
        glob_feats.extend(anchor_stats[pos][:3])
    glob_feats.append(anchor_stats[3][0] - anchor_stats[1][0])
    glob_feats.append(anchor_stats[3][1] * logit_entropy)
    glob_feats.extend([
        logit_std * np.mean(norm_diffs) if len(norm_diffs) > 0 else 0,
        logit_entropy * logit_std,
    ])
    return np.array(seq_feats, dtype=np.float32), np.array(glob_feats, dtype=np.float32)


def load_halueval_real(n):
    dataset = load_dataset("pminervini/HaluEval", "qa_samples", revision=DATASET_REVISION)
    samples = []
    for item in dataset["data"]:
        samples.append({
            "question": item["question"], "answer": item["answer"],
            "is_hallucination": 1 if item["hallucination"] == "yes" else 0,
        })
    return samples[:n]


def run_extraction():
    if FEATS_PATH.exists():
        print(f"Features already at {FEATS_PATH} -- skipping extraction.")
        return
    print(f"Loading {MODEL_ID} ...")
    tokenizer = AutoTokenizer.from_pretrained(MODEL_ID)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    model = AutoModelForCausalLM.from_pretrained(
        MODEL_ID, device_map="auto", torch_dtype=torch.float16)
    model.eval()
    print(f"VRAM used: {torch.cuda.memory_allocated()/1e9:.2f} GB")

    print("Loading real HaluEval samples...")
    samples = load_halueval_real(N_SAMPLES)
    print(f"  {len(samples)} samples loaded, hall_rate={np.mean([s['is_hallucination'] for s in samples]):.3f}")

    cfg = Cfg()
    all_seq, all_glob, all_labels = [], [], []
    t0 = time.time()
    for i, sample in enumerate(samples):
        if i % 25 == 0:
            elapsed = time.time() - t0
            eta = (elapsed / max(i, 1)) * (len(samples) - i) / 60
            print(f"  [{i}/{len(samples)}] elapsed={elapsed/60:.1f}min ETA={eta:.0f}min", flush=True)
        try:
            s, g = extract_features(sample["question"], sample["answer"], tokenizer, model, cfg)
            all_seq.append(s)
            all_glob.append(g)
            all_labels.append(sample["is_hallucination"])
        except Exception as e:
            print(f"  skipped sample {i}: {e}")
            continue

    X_seq = np.nan_to_num(np.array(all_seq), nan=0.0)
    X_glob = np.nan_to_num(np.array(all_glob), nan=0.0)
    y = np.array(all_labels)
    print(f"Extraction complete: X_seq={X_seq.shape}, X_glob={X_glob.shape}, hall_rate={1-y.mean():.3f}")
    np.savez_compressed(FEATS_PATH, X_seq=X_seq, X_glob=X_glob, y=y)
    print(f"Saved: {FEATS_PATH}")
    del model
    gc.collect()
    torch.cuda.empty_cache()


CAPACITY = 128
N_SEEDS = 100
EPOCHS = 45
ES_HOLD_FRACTION = 0.15


class SweepMLP(nn.Module):
    def __init__(self, in_dim, hidden):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_dim, hidden), nn.ReLU(), nn.Dropout(0.2),
            nn.Linear(hidden, hidden // 2), nn.ReLU(),
            nn.Linear(hidden // 2, 1),
        )

    def forward(self, x):
        return self.net(x).squeeze(-1)


def train_to_best_checkpoint(X_tr, y_tr, X_sel, y_sel, hidden, epochs, seed):
    torch.manual_seed(seed)
    model = SweepMLP(X_tr.shape[1], hidden)
    opt = torch.optim.Adam(model.parameters(), lr=2e-3, weight_decay=6e-5)
    crit = nn.BCEWithLogitsLoss()
    Xt = torch.tensor(X_tr, dtype=torch.float32)
    yt = torch.tensor(y_tr, dtype=torch.float32)
    Xs = torch.tensor(X_sel, dtype=torch.float32)
    best_auc, best_state, best_epoch = -1.0, None, 0
    for ep in range(epochs):
        model.train(); opt.zero_grad()
        loss = crit(model(Xt), yt); loss.backward(); opt.step()
        model.eval()
        with torch.no_grad():
            probs = torch.sigmoid(model(Xs)).numpy()
        try:
            auc = roc_auc_score(y_sel, probs)
        except ValueError:
            auc = 0.5
        if auc > best_auc:
            best_auc, best_state, best_epoch = auc, {k: v.clone() for k, v in model.state_dict().items()}, ep + 1
    model.load_state_dict(best_state)
    return model, best_epoch


def train_fixed_epochs(X_tr, y_tr, hidden, n_epochs, seed):
    torch.manual_seed(seed)
    model = SweepMLP(X_tr.shape[1], hidden)
    opt = torch.optim.Adam(model.parameters(), lr=2e-3, weight_decay=6e-5)
    crit = nn.BCEWithLogitsLoss()
    Xt = torch.tensor(X_tr, dtype=torch.float32)
    yt = torch.tensor(y_tr, dtype=torch.float32)
    for _ in range(max(n_epochs, 1)):
        model.train(); opt.zero_grad()
        loss = crit(model(Xt), yt); loss.backward(); opt.step()
    model.eval()
    return model


def eval_auc(model, X, y):
    model.eval()
    with torch.no_grad():
        probs = torch.sigmoid(model(torch.tensor(X, dtype=torch.float32))).numpy()
    return float(roc_auc_score(y, probs))


def run_one_seed(X, y, hidden, fold_seed):
    rng = np.random.default_rng(fold_seed)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=fold_seed, stratify=y)
    sc = StandardScaler().fit(X_train)
    X_train, X_test = sc.transform(X_train), sc.transform(X_test)

    skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=fold_seed)
    tr_idx, val_idx = next(iter(skf.split(X_train, y_train)))

    aucs = {}
    model_leaky, _ = train_to_best_checkpoint(
        X_train[tr_idx], y_train[tr_idx], X_train[val_idx], y_train[val_idx], hidden, EPOCHS, fold_seed)
    aucs["leaky"] = eval_auc(model_leaky, X_test, y_test)

    tr2_idx, es_idx = train_test_split(
        tr_idx, test_size=ES_HOLD_FRACTION, stratify=y_train[tr_idx], random_state=fold_seed)
    model_clean, best_epoch = train_to_best_checkpoint(
        X_train[tr2_idx], y_train[tr2_idx], X_train[es_idx], y_train[es_idx], hidden, EPOCHS, fold_seed)
    aucs["clean"] = eval_auc(model_clean, X_test, y_test)

    model_clean_matched = train_fixed_epochs(X_train[tr_idx], y_train[tr_idx], hidden, best_epoch, fold_seed)
    aucs["clean_matched"] = eval_auc(model_clean_matched, X_test, y_test)

    y_val_permuted = rng.permutation(y_train[val_idx])
    model_placebo, _ = train_to_best_checkpoint(
        X_train[tr_idx], y_train[tr_idx], X_train[val_idx], y_val_permuted, hidden, EPOCHS, fold_seed)
    aucs["placebo"] = eval_auc(model_placebo, X_test, y_test)

    return aucs


def run_leakage_test():
    print(f"\n{'='*60}\nStep 2: Real-feature checkpoint-selection-leakage test (Qwen2.5-7B)\n{'='*60}")
    d = np.load(FEATS_PATH)
    X_seq, X_glob, y = d["X_seq"], d["X_glob"], d["y"]
    X = np.hstack([X_seq.reshape(X_seq.shape[0], -1), X_glob])
    print(f"Combined feature matrix: {X.shape}, hall_rate={1-y.mean():.3f}")

    all_aucs = {k: [] for k in ["leaky", "clean", "clean_matched", "placebo"]}
    for seed in range(N_SEEDS):
        aucs = run_one_seed(X, y, CAPACITY, seed)
        for k, v in aucs.items():
            all_aucs[k].append(v)
        if (seed + 1) % 10 == 0:
            print(f"  seed {seed+1}/{N_SEEDS}: "
                  f"leaky={np.mean(all_aucs['leaky']):.4f} clean={np.mean(all_aucs['clean']):.4f} "
                  f"clean_matched={np.mean(all_aucs['clean_matched']):.4f} placebo={np.mean(all_aucs['placebo']):.4f}",
                  flush=True)

    def gap_stats(a, b):
        arr_a, arr_b = np.array(all_aucs[a]), np.array(all_aucs[b])
        gap = arr_a - arr_b
        try:
            _, p = wilcoxon(gap)
        except ValueError:
            p = 1.0
        return {"mean_a": float(arr_a.mean()), "mean_b": float(arr_b.mean()),
                "mean_gap": float(gap.mean()), "std_gap": float(gap.std()), "wilcoxon_p": float(p)}

    gaps = {
        "leaky_minus_placebo": gap_stats("leaky", "placebo"),
        "clean_minus_placebo": gap_stats("clean", "placebo"),
        "clean_matched_minus_placebo": gap_stats("clean_matched", "placebo"),
        "leaky_minus_clean_matched": gap_stats("leaky", "clean_matched"),
    }

    result = {
        "model": MODEL_ID, "n_samples": int(len(y)), "n_seeds": N_SEEDS, "capacity": CAPACITY,
        "feature_dim": int(X.shape[1]), "hall_rate": float(1 - y.mean()),
        "mean_aucs": {k: float(np.mean(v)) for k, v in all_aucs.items()},
        "gaps": gaps,
    }
    print(f"\nMean AUROCs: {result['mean_aucs']}")
    print(f"Gaps: {json.dumps(gaps, indent=2)}")

    out_path = OUT / "real_feature_leakage_test_result_qwen.json"
    with open(out_path, "w") as f:
        json.dump(result, f, indent=2)
    print(f"\nSaved: {out_path}")


def main():
    run_extraction()
    run_leakage_test()


if __name__ == "__main__":
    main()
